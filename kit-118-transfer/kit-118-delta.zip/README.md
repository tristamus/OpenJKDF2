# cloudflare-118

Kit 117 (level playlists) with three fixes from its beta check with two players.

- **Worker:** kit 117's (= 116's = 114's), byte for byte (`src/`, `wrangler.toml`, the package files, `tools/check-site.mjs`).
- **Page:** kit 117's `index.html` (netcode 2), except its table of engine files.
- **Engines:** OpenJKDF2 branch `claude/project-thread-ne9yac` at `b0fbc1f` (PR #111).
- `public/` keeps the engine files of kits 93 to 117 (`--keep 23`), and the five fixed-name files from before
  `build-kit.mjs`.

## What's changed since 117

- **The last level of a playlist without Loop:** the game ends there, so its score screen is the game's last one
  (no countdown, Ok goes to the menu). It now says "That was the playlist's last level." In 117 it showed nothing.
- **Playlist screen:** "Choose Episode:" wrapped before Level Library... and was cut off by the list box: the labels
  are now "Episodes:" and "Levels:". The subtitle took a second line under the Name row: it is now "Up to 6 levels of
  one kind, played one after another."
- **MotS Host Game:** Playlist...'s baseline was 1 game px below "Choose Level:": its rect is 1 higher,
  `{460,245,170,20}` (JK's stays `{460,242,170,20}`, which lined up exactly).

What kit 117 does is in its README; unchanged here.

## Deploy (beta)

In this folder (the package files are 117's, so its `node_modules` works):

```
npx wrangler deploy --env beta
node tools/check-site.mjs https://beta.jediknight.zone
```

- **The deploy:** the same bindings as 117's beta. It should upload 9 asset files: the page and the four new engine
  files with their `.br`.
- **check-site:** each line `ok`, except the expected `zone` line.

## Deploy (live)

After beta passes and the live lobby has no rooms open:

```
npx wrangler deploy --env=""
node tools/check-site.mjs https://jediknight.zone
```

Netcode 2: tabs open on the live site during the deploy need a reload to join new games.

## Rollback

Live: deploy kit 116 (`jkdf2mp-deploy-cloudflare-116`). Beta: kit 117 or 116.
